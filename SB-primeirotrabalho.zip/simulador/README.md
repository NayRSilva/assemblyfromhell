# O Simulador

## Para Compilar: make

## Para rodar: ./simulador algumacoisa.obj

## Para apagar pastas antigas: make clean
